/*
 *  Account.java by Fabian, Isaias, Daniel, Hao, John, & Humberto
 *  The point of account java is to be able to store the user's information
 *  CS3443 - Section 02 
 *  
 */
package application;

//Import necessary packages
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

/* Account class is the basis of Hydration.  Users will create an account and their
 * personal information (name, age, etc.) will be stored and tracked here while
 * they keep track of their hydration information.
 */
public class Account {
	 private String user;		// Users name info for login
	 private String password;	// Users password for login
	 private int age;			// Users age
	 private double weight;		// Users weight
	 private int waterCoins;	// Users total waterCoins
	 private int intake;		//Users intake of water
	 private boolean challenge; 	//Users first challenge boolean
	 private boolean challengeTwo; 	//Users second challenge boolean

	 
	 // Account constructor - Invoked when new user successfully creates an account for the app.
	 /*
	  * @params user, password, age, weight
	  */
	 public Account(String user,String password, int age,double weight){
		 // Set necessary values for new user
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = 0;
		 this.intake = 0;
		 this.challenge = false;
		 this.challengeTwo = false;
	 }
	 
	 // Account Constructor - Invoked to get a current users information
	 /*
	  * @params user, password, age, weight, intake, watercoins, challenge, challengeTwo
	  * The main information about the user such as their username and password etc.
	  */
	  public Account(String user,String password, int age,double weight, int intake, int watercoins,boolean challenge, boolean challengeTwo) {
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = watercoins;
		 this.intake = intake;
		 this.challenge = challenge;
		 this.challengeTwo = challengeTwo;
	 }
	
// ***************** GETTERS AND SETTERS ******************** //

	// getUser - returns user 
	public String getUser() {
		return user;
	}

	// getUser - sets user 
	public void setUser(String user) {
		this.user = user;
	}

	// getPassword - returns user password 
	public String getPassword() {
		return password;
	}

	// setPassword - sets user password 
	public void setPassword(String password) {
		this.password = password;
	}

	// getAge - returns user age
	public int getAge() {
		return age;
	}

	// setAge - sets users age
	public void setAge(int age) {
		this.age = age;
	}

	// getWeight - returns uses weight
	public double getWeight() {
		return weight;
	}

	// setWeight - sets users weight
	public void setWeight(double weight) {
		this.weight = weight;
	}

	// getWaterCoins - gets users watercoins
	public int getWaterCoins() {
		return waterCoins;
	}

	// setWaterCoins - sets users watercoins
	public void setWaterCoins(int waterCoins) {
		this.waterCoins = waterCoins;
	}

	// setIntake - Set users daily intake
	public void setIntake(int water) {
		this.intake = water;
	}

	// getIntake - Get users daily intake
	public int getIntake() {
		return intake;
	}

	 // getChallenge - get users first challenge flag
	public boolean getChallenge(){return challenge;}
	
	// setChallenge - set users first challenge 
	public void setChallenge(boolean flag) {
		this.challenge = flag;
	}
	
	 // getChallengeTwo - get users seconds challenge flag
	public boolean getChallengeTwo() {
		return challengeTwo;
	}
		
	// setChallengeTwo - set users seconds challenge 
	public void setChallengeTwo(boolean flag) {
		this.challengeTwo = flag;
	}
}
