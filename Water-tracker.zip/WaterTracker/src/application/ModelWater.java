package application;

import java.util.*;

import javafx.scene.control.Alert;

import java.io.*;

public class ModelWater {
	
	public int SignUp(String user, String password,int age, double weight){
		
		//Check if user exists
		if (ifValidUser(user,password,age,weight))
		     return 1;
		//return 1 : user already exists
		
		
		//checks if user and passwords are not with in 10 characters 
		//and don't have a mix of numbers and characters in password
		if(!user.matches("[a-zA-z0-9_]{4,20}") || !password.matches("[a-zA-z0-9/@$%!^&*()?_]{15,20}")
			|| user.isEmpty() ||  password.isEmpty())
			return 2;
		//return 2 : error check user and passwords follow this format
		
		
		//check if age is  <= 0 or >= 130
		if(age <= 0 || age >= 130)
			return 3;
		//return 3 : error age must be in range 0 < age <= 130

		//check if weight is  <= 0.0 or >= 700.0
		if(weight <= 0.0 || weight >= 700.0)
			return 4;
		//return 4 : error age must be in range 0 < age <=  700.0
		
		
		return 0; // make user along with the users water coins
	}

	public boolean ifValidUser(String user, String password,int age,double weight){
		
		//check if username and password exist with 
		//any of the accounts in the arraylist
		Account accnt = new Account(user,password,age,weight);
		accnt.takeIn("Users/accounts.csv");
		for(int i = 0; i < accnt.getAccounts().size(); i++){
			if(accnt.getAccounts().get(i).getUser().equals(user))
               return true;
		}
		
		
		
		return false;
	}
	
	public void DialogInfo(String title,String content,String header){
		
		// Alert //
		Alert alert = new Alert(Alert.AlertType.INFORMATION);

		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		
		//display pop up
		alert.showAndWait();
	}
	
}
