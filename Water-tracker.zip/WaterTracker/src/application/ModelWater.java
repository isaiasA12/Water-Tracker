package application;

import java.util.*;

import javafx.scene.control.Alert;

import java.io.*;



public class ModelWater {
	public Account user; // user to keep track of
	private ArrayList<Account> accounts = new ArrayList<Account>();	// ArrayList of accounts
	public int SignUp(String user, String password,int age, double weight){
		
		//Check if user exists
		if (ifValidUser(user))
		     return 1;
		//return 1 : user already exists
		
		
		//checks if user and passwords are not with in 10 characters 
		//and don't have a mix of numbers and characters in password
		if(!user.matches("[a-zA-z0-9_]{4,20}") || !password.matches("[a-zA-z0-9/@$%!^&*()?_]{15,20}")
			|| user.isEmpty() ||  password.isEmpty())
			return 2;
		//return 2 : error check user and passwords follow this format
		
		
		//check if age is  <= 0 or >= 130
		if(age <= 0 || age >= 130)
			return 3;
		//return 3 : error age must be in range 0 < age <= 130

		//check if weight is  <= 0.0 or >= 700.0
		if(weight <= 0.0 || weight >= 700.0)
			return 4;
		//return 4 : error age must be in range 0 < age <=  700.0
		
		
		return 0; // make user along with the users water coins
	}

	
	public void DialogInfo(String title,String content,String header){
		
		// Alert //
		Alert alert = new Alert(Alert.AlertType.INFORMATION);

		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		
		//display pop up
		alert.showAndWait();
	}
	/* Save function - Creates a new user and password information that is written to a highly secured
	 ** CSV file.  Tracks all of users personal information used for future logins
	 */
	 public void save(){
		 //output user data into text file (sign up)
		 File users = new File("Users/accounts.csv"); // file for animal
		 String combinedStr = "";
		 //zone//
		//combines the information from account and separates each element by ","
		for(int i = 0; i < this.accounts.size();i++){
			combinedStr += this.accounts.get(i).getUser() + "," 
					+ this.accounts.get(i).getPassword() + "," 
					+ this.accounts.get(i).getAge() + ","
					+ this.accounts.get(i).getWeight() + ","
					+ this.accounts.get(i).getIntake() + ","
					+ this.accounts.get(i).getWaterCoins() + ","
					+ this.accounts.get(i).getChallenge() + ","
					+ this.accounts.get(i).getChallengeTwo() +"\n";

		}
		//writes to file
		try {
			System.out.println(combinedStr);
			FileWriter newFil = new FileWriter(users,false);
			newFil.write(combinedStr);
			newFil.close();
		} catch (IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }

	 // takeIn function - Takes in data that is comma delimited updates the accounts arrayList
	 public void takeIn(String Path){
		 // Get file path
		 File file = new File(Path);
		 try {
			 Scanner read = new Scanner(file);
			 while(read.hasNext()){ 
				 String data = read.nextLine();
				 String[] values = data.split(","); 
	  
				 String username = values[0];
				 String password = values[1];
				 int age = Integer.parseInt((values[2]));
				 double weight = Double.parseDouble(values[3]);
				 int intake = Integer.parseInt(values[4]);
				 int waterCoins = Integer.parseInt(values[5]);
				 String flag = values[6];
				 String flag2 = values[7];
				 boolean cFlag = false;
				 boolean cFlag2 = false;
				 if(flag.equals("true"))
					 cFlag = true;
				 
				 if(flag2.equals("true"))
					 cFlag2 = true;
				
				 Account a = new Account(username,password,age,weight,intake,waterCoins,cFlag, cFlag2);
				 accounts.add(a);
			 }
			 read.close();
		 }	
		 catch(FileNotFoundException e) {
			 e.printStackTrace();
			 System.out.println("file not found");
		 }
	}
	
		public Account getAccntByName(String username) {
			
			for(int i = 0; i < accounts.size(); i++){
				if(accounts.get(i).getUser().equals(username))
	               return accounts.get(i);
			}
			return null;
		}
			
		public void SetNewAccnt(Account user) {
			
			for(int i = 0; i < accounts.size(); i++){
				if(accounts.get(i).getUser().equals(user.getUser())){
	               accounts.remove(i);
				   accounts.add(user);
				   return;
				}  
			}
			
		}
			
		public boolean ifValidUserNPass(String username,String password){
			
			//check if username and password exist with 
			//any of the accounts in the arraylist
			for(int i = 0; i < accounts.size(); i++){
				if(accounts.get(i).getUser().equals(username) && accounts.get(i).getPassword().equals(password))
	               return true;
			}
			
			return false;
		}
		public boolean ifValidUser(String username){
			
			//check if username and password exist with 
			//any of the accounts in the arraylist
			for(int i = 0; i < accounts.size(); i++){
				if(accounts.get(i).getUser().equals(username))
	               return true;
			}
			
			return false;
		}
		//Convert water intake to coint
		public void converter(Account user){
			int water = user.getIntake();
			int coins = 0;
			int userCoins = user.getWaterCoins();
			
			if(water >= 8){
				for(int i=0 ; i<water; i++){
					if(i % 8 == 0){
						coins += 1;
					}
				}
			}
			user.setWaterCoins(coins + userCoins);
		}


		// getAccounts - returns accounts
		public ArrayList<Account> getAccounts() {
			return accounts;
		}

		// setAccounts - returns accounts
		public void setAccounts(ArrayList<Account> accounts) {
			this.accounts = accounts;
		}
		
		public void setUser(Account a){
			this.user = a;
		}
		public Account getUser() { return user; }

}
