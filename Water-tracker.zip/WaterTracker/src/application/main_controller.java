package application;

// Import necessary packages
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Sphere;

/* main_cointroller class is the .....
 * 
 */
public class main_controller implements Initializable {
	@FXML
	private Button button;
	@FXML
	private Button amount;
	@FXML
	private Hyperlink hyperlink;
	@FXML
	private AnchorPane scene2_anchorRoot;
	@FXML
	private TextField user_Field;		// Users input for userName registration
	@FXML
	private TextField password_Field;	// Users input for password registration
	@FXML
	private TextField age_Field;		// Users input for age registration
	@FXML
	private TextField weight_Field;		// Users input for weight registration
	@FXML
	private CheckBox box;				//Check box
	@FXML
	private TextField water_amount;		//User inputs a custom water intake

	private static String username =""; 	// users name
	private static String password = ""; 	// users password
	private static int age = 0;  			// users age
	private static int water = 0;			//total amount of intake
	private static int intake=0;			//intake of water
	private static double weight = 0.0; 	// users weight
	private static int waterCoins = 0; 	// users currency 
	private static Account user; 			// user
	private  ModelWater ml = new ModelWater();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ml.takeIn("Users/accounts.csv");
	}
	
	// can be reduced with a switch statement
	/* Sign_up is the immediate fxml page that the user will encounter.  User can create an account 
	** or sign in if they already have one.
	*/
	public void Sign_Up(ActionEvent event) throws IOException{
		AnchorPane root = FXMLLoader.load(getClass().getResource("Sign up.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
	} 
	
	/* Option determines multiple cases using the users input information from the text fields of sign-in or register.
	** Using the values that the user entered, the function SignUp will be invoked to ensure that the users credentials
	** are correct and/or valid for signing up/in with our application.  If successfully able to sign-in or register,
	** user is then redirected to the options.fxml.
	*/
	public void Option(ActionEvent event) throws IOException{
        
        
		// If user selects register button, grab their inputs from the four required text boxes
		if(((Button)event.getSource()).getText().equals("Register")){
			// Grabs information from sign-in text boxes  
			this.username = user_Field.getText();
			this.password = password_Field.getText();
			this.username = user_Field.getText();
			this.password = password_Field.getText();
			
			// Ensure user inputs valid age and weight values
			try{
				this.age = Integer.parseInt(age_Field.getText());
 				this.weight = Double.parseDouble(weight_Field.getText());
			}catch(Exception e ){
				if(this.age < 0)
				this.age =0;
				if(this.weight < 0)
				this.weight = 0.0;
			}
			
			/* Using the input the user has entered, SignUp is invoked which returns an integer value that
			 * determines if the users information is valid for registering.  If incorrect, the
			 * user will be prompted with a warning message.
			 */
			switch(ml.SignUp(username, password, age, weight)){
			// Sign-up information is corret and valid.  Saves account and takes them to options.fxml 
			case 0:
			    
				user = new Account(username,password,age,weight);
			    ml.getAccounts().add(user);
			    ml.save();
			    ml.setUser(user);
	        	AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
	     		scene2_anchorRoot.getChildren().setAll(root);
	     		break;
	     	// User already exists, user must make new username
			case 1:
	        	ml.DialogInfo("User already exist","please change the username","User Already Exist!:");
	        	break;
	        // Users username or password does not match specified requirements
			case 2:
	        	ml.DialogInfo("Username and password","username must be alphabetical characters(can contain an '_'and digits) and 5-20 characters long)\n"
	        		       	+ "password must be 15-20 characters long","Username or Password incorrectly formatted!:");
	        	break;
	        // Users age is not in correct range
			case 3:
	        	ml.DialogInfo("Age: out of bounds","Age must be in the range of 0 =< age <= 130","Age Not In Range!:");
	        	break;
	        // Users weight is not in correct range	
			case 4:
	        	ml.DialogInfo("Weight: out of bounds","weight must be in the range of 0.0 =< weight <= 700.0","Weight not in range");
	        	break;
	        	}
			// User selected Log in, invokes ifValidUser function to ensure user has an account already created
			} else if(((Button)event.getSource()).getText().equals("Log in")){
				// Grabs information from sign-in text boxes  
				this.username = user_Field.getText();
				this.password = password_Field.getText();
				if(ml.ifValidUser(username)){
					// account now has 
					this.user = ml.getAccntByName(username);
					
					AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
				    scene2_anchorRoot.getChildren().setAll(root);
					
				}
				// Users login information did not match anything in the books.
				else
					ml.DialogInfo("Incorrect User/Password", "password or username do not exist", "Invalid User or Password!:");
			}
			else {

			AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
			scene2_anchorRoot.getChildren().setAll(root);

    	}
	} 
	
	// FMXL loader for waterTracker.fxml
	public void Menu(ActionEvent event) throws IOException{
		for(Account a: ml.getAccounts()){
			System.out.println(a.getUser());
		}
		AnchorPane root = FXMLLoader.load(getClass().getResource("waterTracker.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);

	} 
	
	// FMXL loader for Rewards.fxml
	public void Rewards(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Rewards.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
	} 
	
	// FMXL loader for Tracker.fxml
	public void Tracker(ActionEvent event) throws IOException{
		AnchorPane root = FXMLLoader.load(getClass().getResource("Tracker.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
	} 

	/*
	   addWater will add water intake to the user water intake and will
	   update to the new values
	 */
	@FXML
	public void addWater(ActionEvent e) throws IOException {
		//Update the user informatiom
		if(((Button)e.getSource()).getText().equals("64 oz")) { user.setIntake(user.getIntake() + 64); }
		if(((Button)e.getSource()).getText().equals("32 oz")) { user.setIntake(user.getIntake() + 32); }
		if(((Button)e.getSource()).getText().equals("16 oz")) { user.setIntake(user.getIntake() + 16); }
		if(((Button)e.getSource()).getText().equals("8 oz")) { user.setIntake(user.getIntake() + 8); }
		water = user.getIntake();
	}
	/*
		addCustomWater will add a cusom number of water to the user's intake
	 */
	@FXML
	public void addCustomWater(ActionEvent e){

		if(box.isSelected()){
			try {
				intake = Integer.parseInt(water_amount.getText());
				if(intake < 0 ){ml.DialogInfo("Incorrect Amount of water", "Amount is negative", "Invalid Amount!:");}
				else {
					user.setIntake(user.getIntake() + intake);
					water = user.getIntake();
				}

			}
			catch (Exception b){
				ml.DialogInfo("Incorrect Amount of water", "Amount is 0", "Invalid Amount!:");
				intake = 0;
				user.setIntake(user.getIntake()+intake);
				water = user.getIntake();
			}
		}


	}
	// FMXL loader for Goals.fxml
	public void Goals(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Goals.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
	} 
	
	public void Airpods(ActionEvent event) throws IOException{
		AnchorPane root = FXMLLoader.load(getClass().getResource("Airpods.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
	} 
	
	
}
