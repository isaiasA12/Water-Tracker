package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Sphere;

public class main_controller implements Initializable {
	@FXML
	private Button button;
	@FXML
	private Button butt;
	@FXML
	private Button butt2;
	@FXML
	private AnchorPane scene2_anchorRoot;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	}
  // ca be reduced with a switch statement
	public void Sign_Up(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Sign up.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Option(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Menu(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("waterTracker.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Rewards(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Rewards.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Tracker(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Tracker.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Goals(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Goals.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
}
