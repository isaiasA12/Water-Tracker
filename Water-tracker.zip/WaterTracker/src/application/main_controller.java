package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Sphere;

public class main_controller implements Initializable {
	@FXML
	private Button button;
	@FXML
	private AnchorPane scene2_anchorRoot;
	
	@FXML
	private TextField user_Field;
	@FXML
	private TextField password_Field;
	@FXML
	private TextField age_Field;
	@FXML
	private TextField weight_Field;
	
	
	private String username =""; // user's name
	private String password = ""; //user's password
	private int age = 0;  // age of user
	private double weight = 0.0; // weight of user
	private int waterCoins = 0; // users currency 
	
	private ModelWater ml = new ModelWater();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	}
  // ca be reduced with a switch statement
	public void Sign_Up(ActionEvent event) throws IOException{
		AnchorPane root = FXMLLoader.load(getClass().getResource("Sign up.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Option(ActionEvent event) throws IOException{
           
		this.username = user_Field.getText();
		this.password = password_Field.getText();
         
		
		if(((Button)event.getSource()).getText().equals("Register")){
			this.username = user_Field.getText();
			this.password = password_Field.getText();
			
			try{
				this.age = Integer.parseInt(age_Field.getText());
 				this.weight = Double.parseDouble(weight_Field.getText());
			}catch(Exception e ){
				if(this.age < 0)
				this.age =0;
				if(this.weight < 0)
				this.weight = 0.0;
			}
			
			
			switch(ml.SignUp(username, password, age, weight)){
	         case 0:
	        	Account a = new Account(username,password,age,weight);
	        	a.getAccounts().add(a);
	        	a.takeIn("Users/accounts.csv");
	        	a.save();
	        	AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
	     		scene2_anchorRoot.getChildren().setAll(root);
	     		break;
	         case 1:
	        	ml.DialogInfo("User already exist","please change the username","User Already Exist!:");
	        	break;
	         case 2:
	        	ml.DialogInfo("Username and password","username must be alphabetical characters(can contain an '_'and digits) and 5-20 characters long)\n"
	        		       	+ "password must be 15-20 characters long","Username or Password incorrectly formatted!:");
	        	break;
	         case 3:
	        	ml.DialogInfo("Age: out of bounds","Age must be in the range of 0 =< age <= 130","Age Not In Range!:");
	        	break;
	         case 4:
	        	ml.DialogInfo("Weight: out of bounds","weight must be in the range of 0.0 =< weight <= 700.0","Weight not in range");
	        	break;
	        	 
			}
		   }else if(((Button)event.getSource()).getText().equals("Log in")){
				if(ml.ifValidUser(username, password, age, weight)){
					AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
				    scene2_anchorRoot.getChildren().setAll(root);
				}
				else
					ml.DialogInfo("Incorrect User/Password", "password or username do not exist", "Invalid User or Password!:");
		 }else{	
			AnchorPane root = FXMLLoader.load(getClass().getResource("Options.fxml"));
			scene2_anchorRoot.getChildren().setAll(root);
    	}
	} 
	public void Menu(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("waterTracker.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Rewards(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Rewards.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Tracker(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Tracker.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
	public void Goals(ActionEvent event) throws IOException{
		
		AnchorPane root = FXMLLoader.load(getClass().getResource("Goals.fxml"));
		scene2_anchorRoot.getChildren().setAll(root);
		
	} 
}
