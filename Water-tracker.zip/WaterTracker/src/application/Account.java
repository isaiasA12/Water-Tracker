package application;

//Import necessary packages
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

/* Account class is the basis of wetMeMore.  Users will create an account and their
 * personal information (name, age, etc.) will be stored and tracked here while
 * they keep track of their hydration information.
 */
public class Account {
	 private String user;		// Users name info for login
	 private String password;	// Users password for login
	 private int age;			// Users age
	 private double weight;		// Users weight
	 private int waterCoins;	// Users total waterCoins
	 private int intake;		//Users intake of water
	 private boolean challenge; //User challenges flah
	 private boolean challengeTwo; //User challenges flah

	 
	 // Account constructor - Invoked when new user successfully creates an account for the app.
	 public Account(String user,String password, int age,double weight){
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = 0;
		 this.intake = 0;
		 this.challenge = false;
		 this.challengeTwo = false;

		 
	 }
	 
	 // Account Function returns returns information of the user.
	  public Account(String user,String password, int age,double weight, int intake, int watercoins,boolean challenge, boolean challengeTwo) {
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = watercoins;
		 this.intake = intake;
		 this.challenge = challenge;
		 this.challengeTwo = challengeTwo;

	 }
	
// ***************** GETTERS AND SETTERS ******************** //

	// getUser - returns user 
	public String getUser() {
		return user;
	}

	// getUser - sets user 
	public void setUser(String user) {
		this.user = user;
	}

	// getPassword - returns user password 
	public String getPassword() {
		return password;
	}

	// setPassword - sets user password 
	public void setPassword(String password) {
		this.password = password;
	}

	// getAge - returns user age
	public int getAge() {
		return age;
	}

	// setAge - sets users age
	public void setAge(int age) {
		this.age = age;
	}

	// getWeight - returns uses weight
	public double getWeight() {
		return weight;
	}

	// setWeight - sets users weight
	public void setWeight(double weight) {
		this.weight = weight;
	}

	// getWaterCoins - gets users watercoins
	public int getWaterCoins() {
		return waterCoins;
	}

	// setWaterCoins - sets users watercoins
	public void setWaterCoins(int waterCoins) {
		this.waterCoins = waterCoins;
	}

	//set the intake
	public void setIntake(int water){this.intake = water;}

	//get the intake
	public int getIntake(){return  intake;}

	 //get the challenge flag
	public boolean getChallenge(){return challenge;}
	
	//set the challenge flag
	public void setChallenge(boolean flag){this.challenge =flag;}
	
	 //get the challenge flag
	public boolean getChallengeTwo(){return challengeTwo;}
		
	//set the challenge flag
	public void setChallengeTwo(boolean flag){this.challengeTwo =flag;}
}
