package application;

//Import necessary packages
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

/* Account class is the basis of wetMeMore.  Users will create an account and their
 * personal information (name, age, etc.) will be stored and tracked here while
 * they keep track of their hydration information.
 */
public class Account {
	 private ArrayList<Account> accounts = new ArrayList<Account>();	// ArrayList of accounts
	 private String user;		// Users name info for login
	 private String password;	// Users password for login
	 private int age;			// Users age
	 private double weight;		// Users weight
	 private int waterCoins;	// Users total waterCoins
	 
	 // Account constructor - Invoked when new user successfully creates an account for the app.
	 public Account(String user,String password, int age,double weight, int waterCoins){
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = waterCoins;
	 }
	 
	 // Account Function returns returns information of the user.
	  public Account(String user,String password, int age,double weight) {
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = 0;
	 }
	 
	 /* Save function - Creates a new user and password information that is written to a highly secured
	 ** CSV file.  Tracks all of users personal information used for future logins
	 */
	 public void save(){
		 //output user data into text file (sign up)
		 File users = new File("Users/accounts.csv"); // file for animal
		 String combinedStr = "";
		 //zone//
		//combines the information from account and separates each element by ","
		for(int i = 0; i < this.accounts.size();i++){
			combinedStr += this.accounts.get(i).getUser() + "," 
					+ this.accounts.get(i).getPassword() + "," 
					+ this.accounts.get(i).getAge() + ","
					+ this.accounts.get(i).getWeight() + ","
					+ this.accounts.get(i).getWaterCoins() + "\n";
		}
		//writes to file
		try {
			System.out.println(combinedStr);
			FileWriter newFil = new FileWriter(users,false);
			newFil.write(combinedStr);
			newFil.close();
		} catch (IOException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 // takeIn function - Takes in data that is comma delimited updates the accounts arrayList
	 public void takeIn(String Path){
		 // Get file path
		 File file = new File(Path);
		 try {
			 Scanner read = new Scanner(file);
			 while(read.hasNext()){ 
				 String data = read.nextLine();
				 String[] values = data.split(","); 
	  
				 String username = values[0];
				 String password = values[1];
				 int age = Integer.parseInt((values[2]));
				 double weight = Double.parseDouble(values[3]);
				 int waterCoins = Integer.parseInt(values[4]);
			
				 Account a = new Account(username,password,age,weight,waterCoins);
				 accounts.add(a);
			 }
			 read.close();
		 }	
		 catch(FileNotFoundException e) {
			 e.printStackTrace();
			 System.out.println("file not found");
		 }
	}

	
// ***************** GETTERS AND SETTERS ******************** //
	 
	// getAccounts - returns accounts
	public ArrayList<Account> getAccounts() {
		return accounts;
	}

	// setAccounts - returns accounts
	public void setAccounts(ArrayList<Account> accounts) {
		this.accounts = accounts;
	}

	// getUser - returns user 
	public String getUser() {
		return user;
	}

	// getUser - sets user 
	public void setUser(String user) {
		this.user = user;
	}

	// getPassword - returns user password 
	public String getPassword() {
		return password;
	}

	// setPassword - sets user password 
	public void setPassword(String password) {
		this.password = password;
	}

	// getAge - returns user age
	public int getAge() {
		return age;
	}

	// setAge - sets users age
	public void setAge(int age) {
		this.age = age;
	}

	// getWeight - returns uses weight
	public double getWeight() {
		return weight;
	}

	// setWeight - sets users weight
	public void setWeight(double weight) {
		this.weight = weight;
	}

	// getWaterCoins - gets users watercoins
	public int getWaterCoins() {
		return waterCoins;
	}

	// setWaterCoins - sets users watercoins
	public void setWaterCoins(int waterCoins) {
		this.waterCoins = waterCoins;
	}
		
	 
}
