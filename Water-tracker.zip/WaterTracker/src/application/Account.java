package application;

import java.util.ArrayList;
import java.util.Scanner;


import java.io.*;
public class Account {
	 private ArrayList<Account> accounts = new ArrayList<Account>();
	 private String user;
	 private String password;
	 private int age;
	 private double weight;
	 private int waterCoins;
	 
	 public Account(String user,String password, int age,double weight, int waterCoins){
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = waterCoins;
		 
	 }
	 
	 public Account(String user,String password, int age,double weight){
		 this.user = user;
		 this.password = password;
		 this.age = age;
		 this.weight = weight;
		 this.waterCoins = 0;
		
	 }
	 
	 
	 public void save(){
		 //output user data into text file (sign up)
		
			File users = new File("Users/accounts.csv"); // file for animal
			String combinedStr = "";
			
			//zone//
			//combines the information from account and separates each element by ","
			for(int i = 0; i < this.accounts.size();i++){
				combinedStr += this.accounts.get(i).getUser() + "," 
							+ this.accounts.get(i).getPassword() + "," 
						    + this.accounts.get(i).getAge() + ","
						    + this.accounts.get(i).getWeight() + ","
						    + this.accounts.get(i).getWaterCoins() + "\n";
			}
			//writes to file
				try {
					System.out.println(combinedStr);
					FileWriter newFil = new FileWriter(users,false);
					newFil.write(combinedStr);
					newFil.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				  
	 }
	 
	public void takeIn(String Path){
		// takes in data that is comma delimited
		//updates the accounts arrayList
		 File file = new File(Path);
		 
		 try{
	       Scanner read = new Scanner(file);
			 while(read.hasNext()){
				 
			  String data = read.nextLine();
			  String[] values = data.split(","); 
			  
			  String username = values[0];
			  String password = values[1];
			  int age = Integer.parseInt((values[2]));
			  double weight = Double.parseDouble(values[3]);
			  int waterCoins = Integer.parseInt(values[4]);
			
			  Account a = new Account(username,password,age,weight,waterCoins);
			  accounts.add(a);
			 }
			 read.close();
		 }catch(FileNotFoundException e){
			 e.printStackTrace();
			 System.out.println("file not found");
		 }
		 
			
		
	}

	
	/*
	 * Getters and setters
	 */
	
	
	public ArrayList<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(ArrayList<Account> accounts) {
		this.accounts = accounts;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getWaterCoins() {
		return waterCoins;
	}

	public void setWaterCoins(int waterCoins) {
		this.waterCoins = waterCoins;
	}
		
	 
}
